<?php
/**
* Plugin Name: one-click-install
* Plugin URI: themetrademark.com
* Description: A plugin to create custom post type, metabox,...
* Version:  1.0
* Author: Themes Trademark
* Author URI: themetrademark.com
* License:  GPL2
*/


include dirname( __FILE__ ) . '/init.php';

return true;